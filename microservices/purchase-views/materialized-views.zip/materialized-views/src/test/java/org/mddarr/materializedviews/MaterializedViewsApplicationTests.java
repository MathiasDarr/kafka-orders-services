package org.mddarr.materializedviews;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MaterializedViewsApplicationTests {

	@Test
	void contextLoads() {
	}

}
